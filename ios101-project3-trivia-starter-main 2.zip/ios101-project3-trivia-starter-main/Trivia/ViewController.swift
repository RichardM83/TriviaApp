//
//  ViewController.swift
//  Trivia
//
//  Created by Richard Martinez on 10/3/23.
//

import UIKit

struct Question {
    let text: String
    let options: [String]
    let correctAnswerIndex: Int
}

class ViewController: UIViewController {

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answer1: UIButton!
    @IBOutlet weak var answer2: UIButton!
    @IBOutlet weak var answer3: UIButton!
    @IBOutlet weak var answer4: UIButton!
    
    @IBOutlet weak var progressbar: UIProgressView!
    
    
    
    var questions: [Question] = [
            Question(text: "Whats 2 + 1?", options: ["1", "2", "3", "4"], correctAnswerIndex: 2),
            Question(text: "What color is grass?", options: ["Green", "Black", "Orange", "White"], correctAnswerIndex: 0),
            Question(text: "Where is Earth located?", options: ["Solar System", "Center of Universe", "Alaska", "Andromeda Galaxy"], correctAnswerIndex: 0)
        ]
    
    var currentQuestionIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        progressbar.setProgress(0.0, animated: false)
        setupQuestion()
//        setupActions()
    }
    
    func setupQuestion() {
        let currentQuestion = questions[currentQuestionIndex]
            questionLabel.text = currentQuestion.text
            answer1.setTitle(currentQuestion.options[0], for: .normal)
            answer2.setTitle(currentQuestion.options[1], for: .normal)
            answer3.setTitle(currentQuestion.options[2], for: .normal)
            answer4.setTitle(currentQuestion.options[3], for: .normal)
    }

    
    @IBAction func optionSelected(_ sender: UIButton) {
        guard let selectedOption = sender.titleLabel?.text else { return }
            print("User selected: \(selectedOption)")
            
            // Increment progress bar value
            let totalQuestions = questions.count
            let progressValue = Float(currentQuestionIndex + 1) / Float(totalQuestions)
            progressbar.setProgress(progressValue, animated: true)
            
            if currentQuestionIndex < questions.count - 1 {
                currentQuestionIndex += 1
                setupQuestion()
            } else {
                print("Quiz finished!")
            }
    }
}
